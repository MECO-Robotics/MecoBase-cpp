#include "base/SystemCheck.h"
#include "base/Replay.h"
#include "base/Telemetry.h"
#include "base/TelemetryPublishers.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <stdexcept>
#include <frc/DriverStation.h>
#include <frc/Errors.h>
#include <frc/RobotController.h>
#include <frc/smartdashboard/SmartDashboard.h>
#include <wpi/json.h>
#include <frc2/command/Commands.h>

namespace base {
SystemCheck::SystemCheck(std::function<void()> neutralize,std::string reportPath,SystemCheckOptions options)
    : neutralize_(std::move(neutralize)),reportPath_(std::move(reportPath)),options_(std::move(options)) {
  if (!std::isfinite(options_.startingVoltage) || options_.startingVoltage < 0 ||
      !std::isfinite(options_.runningVoltage) || options_.runningVoltage < 0 ||
      !std::isfinite(options_.countdownSeconds) || options_.countdownSeconds < 0 || options_.setupPrompt.empty())
    throw std::invalid_argument("Invalid system check options");
  if(!neutralize_) throw std::invalid_argument("System check requires emergency neutralization");
  frc::SmartDashboard::PutBoolean("SystemCheck/Armed",false);
  frc::SmartDashboard::PutBoolean("SystemCheck/SetupConfirmed",false);
  frc::SmartDashboard::PutBoolean("SystemCheck/Start",false);
  frc::SmartDashboard::PutBoolean("SystemCheck/Abort",false);
}
SystemCheck::~SystemCheck() {
  try {
    if(active_) Cancel("System check destroyed");
    if(reservation_ && !reservationEnding_) reservation_->Cancel();
  } catch (...) {
    // Destruction must not terminate the robot if a callback or report fails.
    if(reservation_ && !reservationEnding_) {
      try { reservation_->Cancel(); } catch (...) {}
    }
  }
}
void SystemCheck::ConfigureRequirements(frc2::Requirements requirements) {
  if(active_ || requirements.begin()==requirements.end())
    throw std::invalid_argument("Diagnostic requirements must include controlled subsystems");
  reservedRequirements_ = requirements;
  reservation_.emplace(frc2::cmd::RunEnd([]{},[this]{
    reservationEnding_=true;
    if(active_) Cancel("Diagnostic subsystem ownership interrupted");
    reservationEnding_=false;
  },requirements).WithName("SystemCheckReservation"));
}
void SystemCheck::AddStage(CheckStage stage) {
  AddStageImpl(std::move(stage), nullptr);
}
void SystemCheck::AddStage(CheckStage stage, frc2::CommandPtr command) {
  if (!command)
    throw std::invalid_argument("Diagnostic command stage requires a command");
  AddStageImpl(std::move(stage), std::move(command).Unwrap());
}
void SystemCheck::AddStageImpl(CheckStage stage, std::unique_ptr<frc2::Command> command) {
  if(active_ || stage.name.empty() || (static_cast<bool>(stage.action) == static_cast<bool>(command)) || !stage.evaluate ||
     !std::isfinite(stage.seconds) || stage.seconds<=0 || !std::isfinite(stage.stableSeconds) || stage.stableSeconds<0 || stage.stableSeconds>stage.seconds)
    throw std::invalid_argument("Invalid diagnostic stage");
  if(std::any_of(stages_.begin(),stages_.end(),[&](const auto& other){return other.name==stage.name;}))
    throw std::invalid_argument("Duplicate diagnostic stage");
  stages_.push_back(std::move(stage));
  stageCommands_.push_back(std::move(command));
}
std::string SystemCheck::Interlock(bool starting) const {
  if(!frc::DriverStation::IsDSAttached()) return "Driver Station disconnected";
  if(!frc::DriverStation::IsTestEnabled()) return "Enable Test mode";
  if(frc::DriverStation::IsFMSAttached()) return "FMS attached";
  if(frc::DriverStation::IsEStopped()) return "Emergency stopped";
  const bool brownedOut = replay::ProcessValue<bool>("SystemCheck/BrownedOut", [] {
    return frc::RobotController::IsBrownedOut();
  });
  if(brownedOut) return "Brownout";
  const double battery = replay::ProcessValue<double>("SystemCheck/BatteryVoltage", [] {
    return frc::RobotController::GetBatteryVoltage().value();
  });
  if(!std::isfinite(battery) || battery<(starting ? options_.startingVoltage : options_.runningVoltage)) return "Battery voltage too low";
  const bool armed = replay::ProcessValue<bool>("SystemCheck/Armed", [] {
    return frc::SmartDashboard::GetBoolean("SystemCheck/Armed", false);
  });
  if(!armed) return "Arm the check";
  const bool setupConfirmed = replay::ProcessValue<bool>("SystemCheck/SetupConfirmed", [] {
    return frc::SmartDashboard::GetBoolean("SystemCheck/SetupConfirmed", false);
  });
  if(!setupConfirmed) return options_.setupPrompt;
  return {};
}
bool SystemCheck::Start() {
  if(active_) return false;
  reason_=Interlock(true);
  if(stages_.empty()) reason_="No diagnostic stages configured";
  if(!reservation_) reason_="No diagnostic subsystem requirements configured";
  if(!reason_.empty()) {state_="BLOCKED"; return false;}
  for (const auto& command : stageCommands_) {
    if (!command)
      continue;
    const auto requirements = command->GetRequirements();
    if (!std::all_of(requirements.begin(), requirements.end(), [this](frc2::Subsystem* requirement) {
          return std::find(reservedRequirements_->begin(), reservedRequirements_->end(), requirement) !=
                 reservedRequirements_->end();
        })) {
      reason_ = "Diagnostic command requirements are not reserved by the system check";
      state_ = "BLOCKED";
      return false;
    }
  }
  std::vector<Result> newResults;
  for(const auto& stage:stages_) newResults.push_back({stage.name});
  reservation_->Schedule();
  if(!reservation_->IsScheduled()) {
    reason_="Unable to reserve diagnostic subsystems"; state_="BLOCKED";
    return false;
  }
  try { neutralize_(); }
  catch (...) {
    reservation_->Cancel();
    reason_="Diagnostic neutralization failed"; state_="BLOCKED";
    return false;
  }
  results_=std::move(newResults);
  stage_=-1; countdown_=true; active_=true; state_="COUNTDOWN";
  runTimer_.Restart(); stageTimer_.Restart();
  return true;
}
void SystemCheck::Cancel(std::string reason) {
  if(!active_) return;
  reason_=std::move(reason); state_="ABORTED"; active_=false;
  try { EndStageCommand(true); }
  catch (...) { reason_ += "; diagnostic command cleanup failed"; }
  try { neutralize_(); }
  catch (...) { reason_ += "; diagnostic neutralization failed"; }
  frc::SmartDashboard::PutBoolean("SystemCheck/Armed",false);
  if(stage_>=0 && stage_<static_cast<int>(results_.size())) {
    auto& result=results_[stage_]; result.status="ABORTED"; result.explanation=reason_; result.elapsed=stageTimer_.Get().value();
  }
  runTimer_.Stop(); stageTimer_.Stop();
  if(reservation_ && !reservationEnding_) reservation_->Cancel();
  SaveReport();
}
void SystemCheck::Advance() {
  try { EndStageCommand(false); }
  catch (...) { Cancel("Diagnostic command cleanup failed"); return; }
  try { neutralize_(); }
  catch (...) { Cancel("Diagnostic neutralization failed"); return; }
  while(++stage_<static_cast<int>(stages_.size())) {
    auto& result=results_[stage_]; auto& stage=stages_[stage_];
    bool allowed=std::all_of(stage.prerequisites.begin(),stage.prerequisites.end(),[&](const std::string& name){
      return std::any_of(results_.begin(),results_.begin()+stage_,[&](const Result& previous){return previous.name==name && previous.status=="PASS";});
    });
    if(!allowed) {result.status="SKIPPED";result.explanation="Prerequisite failed";continue;}
    result.status="RUNNING"; stageTimer_.Restart(); stableSince_=-1;
    if (stageCommands_[stage_]) {
      try {
        stageCommandActive_ = true;
        stageCommands_[stage_]->Initialize();
      } catch (const std::exception& exception) {
        Cancel(exception.what());
      } catch (...) {
        Cancel("Diagnostic command initialization threw an unknown exception");
      }
    }
    return;
  }
  active_=false; state_="COMPLETE"; runTimer_.Stop(); stageTimer_.Stop();
  if(reservation_ && !reservationEnding_) reservation_->Cancel();
  frc::SmartDashboard::PutBoolean("SystemCheck/Armed",false); SaveReport();
}
void SystemCheck::EndStageCommand(bool interrupted) {
  if (!stageCommandActive_)
    return;
  stageCommandActive_ = false;
  stageCommands_.at(stage_)->End(interrupted);
}
void SystemCheck::Periodic() {
  const bool abort = replay::ProcessValue<bool>("SystemCheck/Abort", [] {
    return frc::SmartDashboard::GetBoolean("SystemCheck/Abort", false);
  });
  if(abort) {
    frc::SmartDashboard::PutBoolean("SystemCheck/Abort",false);
    // An abort takes precedence over any simultaneous or stale start request.
    frc::SmartDashboard::PutBoolean("SystemCheck/Start",false);
    Cancel();
  }
  const bool start = replay::ProcessValue<bool>("SystemCheck/Start", [] {
    return frc::SmartDashboard::GetBoolean("SystemCheck/Start", false);
  });
  if(start) {
    frc::SmartDashboard::PutBoolean("SystemCheck/Start",false); Start();
  }
  if(active_) {
    auto failure=Interlock(false);
    if(!failure.empty()) Cancel(failure);
    else if(countdown_) {
      if(stageTimer_.Get().value()>=options_.countdownSeconds) {countdown_=false;state_="RUNNING";Advance();}
    } else {
      try {
        auto& stage=stages_.at(stage_); auto& result=results_.at(stage_);
        bool commandFinished = false;
        if (stageCommands_[stage_]) {
          if (stageCommandActive_) {
            auto& command = *stageCommands_[stage_];
            command.Execute();
            commandFinished = command.IsFinished();
            if (commandFinished)
              EndStageCommand(false);
          }
        } else {
          stage.action();
        }
        auto evaluation=stage.evaluate();
        result.elapsed=stageTimer_.Get().value(); result.measurements=evaluation.measurements;
        bool finite=std::all_of(result.measurements.begin(),result.measurements.end(),[](const auto& entry){return std::isfinite(entry.second);});
        if(!finite) {Cancel("Nonfinite diagnostic measurement");return;}
        if(evaluation.passed) {if(stableSince_<0)stableSince_=result.elapsed;}
        else stableSince_=-1;
        for(const auto& [name,value]:result.measurements) {
          telemetry::PostDashboardNumber("SystemCheck/Live/" + name, value);
          replay::RecordOutput("SystemCheck/Live/" + name, value);
        }
        if(commandFinished) {
          result.status = evaluation.passed && stableSince_ >= 0 &&
                                  result.elapsed - stableSince_ >= stage.stableSeconds
                              ? "PASS"
                              : "FAIL";
          result.explanation = evaluation.explanation;
          Advance();
        } else if(result.elapsed>=stage.seconds) {
          result.status=evaluation.passed && stableSince_>=0 && result.elapsed-stableSince_>=stage.stableSeconds ? "PASS" : "FAIL";
          result.explanation=evaluation.explanation; Advance();
        }
      } catch(const std::exception& exception) {Cancel(exception.what());}
        catch(...) {Cancel("Diagnostic stage threw an unknown exception");}
    }
  }
  const std::string state = state_;
  const std::string reason = reason_;
  const std::string stage = active_ && stage_ >= 0 ? stages_[stage_].name : "";
  const std::string report = ReportJson();
  telemetry::PostDashboardString("SystemCheck/State", state);
  telemetry::PostDashboardString("SystemCheck/Reason", reason);
  telemetry::PostDashboardString("SystemCheck/Stage", stage);
  telemetry::PostDashboardString("SystemCheck/ReportJSON", report);
  replay::RecordOutput("SystemCheck/Status", wpi::json{{"state", state}, {"reason", reason}, {"stage", stage}});
}
std::string SystemCheck::ReportJson() const {
  wpi::json stages=wpi::json::array(); bool failed=state_=="ABORTED";
  for(const auto& result:results_) {
    failed|=result.status=="FAIL" || result.status=="ABORTED" || result.status=="SKIPPED";
    stages.push_back({{"name",result.name},{"status",result.status},{"explanation",result.explanation},{"elapsedSeconds",result.elapsed},{"measurements",result.measurements}});
  }
  return wpi::json{{"state",state_},{"reason",reason_},{"elapsedSeconds",runTimer_.Get().value()},
                   {"overallStatus",failed ? "FAIL" : state_=="COMPLETE" ? "PASS" : "NOT_RUN"},{"results",stages}}.dump(2);
}
void SystemCheck::SaveReport() const {
  const auto report = ReportJson();
  replay::RecordOutput("SystemCheck/Report", wpi::json::parse(report));
  if (replay::Active())
    return;
  std::ofstream output(reportPath_); if(output) output<<report<<'\n';
  else FRC_ReportError(frc::warn::Warning, "Could not write system check report: {}", reportPath_);
}
}
